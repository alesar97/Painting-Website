
<?php $__env->startSection("content"); ?>
    <link href="<?php echo e(asset('assets/css/foundation.css')); ?>" rel="stylesheet" type="text/css" />


    <!--SERVICE AREA-->
    <section class="service-area-three section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn">
                        <h2>Our Gallery</h2>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
                    </div>
                </div>
            </div>
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row" style="margin-top: 2em; margin-bottom: 2em;">
                <div class="large-4 columns">
                    <h3>  <?php echo e($item->title); ?></h3>
                    <p>details</p>
                </div>
                <div class="large-8 columns">
                    <div class="twentytwenty-container" data-orientation="horizontal">
                        <img src="<?php echo e(Voyager::image($item->first_image)); ?>" />
                        <img src="<?php echo e(Voyager::image($item->second_image)); ?>" />
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!--SERVICE AREA END-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('myjs'); ?>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\work2\GeorgePaintingL\resources\views/gallery/images.blade.php ENDPATH**/ ?>