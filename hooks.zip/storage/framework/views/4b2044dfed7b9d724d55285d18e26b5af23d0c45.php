
<?php $__env->startSection("content"); ?>

    <link href="<?php echo e(asset('assets/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/lightgallery.css')); ?>" rel="stylesheet">
    <link href="http://vjs.zencdn.net/4.12/video-js.css" rel="stylesheet">
    <!--SERVICE AREA-->
    <section class="service-area-three section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn">
                        <h2>Our Gallery</h2>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, </p>
                    </div>
                </div>
            </div>
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Hidden video div -->
                <div style="display:none;" id="video<?php echo e($item->id); ?>">
                    <?php if(json_decode($item->video) !== null): ?>
                        <?php $__currentLoopData = json_decode($item->video); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <video class="lg-video-object lg-html5 video-js vjs-default-skin" controls preload="none">
                                <source src="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($file->download_link) ?: ''); ?>" type="video/mp4">
                                Your browser does not support HTML5 video.
                            </video>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <video class="lg-video-object lg-html5 video-js vjs-default-skin" controls preload="none">
                            <source src="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($item->video)); ?>" type="video/mp4">
                            Your browser does not support HTML5 video.
                        </video>

                    <?php endif; ?>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <ul id="video-gallery">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-poster="<?php echo e(Voyager::image($item->image)); ?>" data-sub-html="video caption1" data-html="#video<?php echo e($item->id); ?>" class="col-md-6" >
                    <img src="<?php echo e(Voyager::image($item->image)); ?>" style="width: 50%;height: 300px;" />
                </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>
    </section>
    <!--SERVICE AREA END-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('myjs'); ?>

    <script src="<?php echo e(asset('assets/js/lightgallery-all.js')); ?>"></script>
    <script src="http://vjs.zencdn.net/4.12/video.js"></script>

    <script>
        $(function () {
            $('#video-gallery').lightGallery();
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\work2\GeorgePaintingL\resources\views/gallery/videos.blade.php ENDPATH**/ ?>