<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Validator;

class ContactController extends Controller
{
    //
    public function index(){
        return view("contact");
    }
    public function store( Request $request){
        $validateErrors =   Validator::make($request->all(),
            [
                'name'=>'required|string:min:3|max:250',
                'email'=>'required|email|string:min:3|max:250',
                'phone'=>'required|digits:10',
                'message'=>'required|string|min:3:max:4000',

            ]);
        if($validateErrors->fails()){
            return response()->json(['status'=>201,'message' => $validateErrors->errors()->first()]);
        } // end if fails .

        ContactMessage::create([
            "name"=>$request->input("name"),
            "email"=>$request->input("email"),
            "phone"=>$request->input("phone"),
            "message"=>$request->input("message"),

        ]);


        return response()->json(['status'=>200,'message' => 'Your Quote Registered Success']);
    }
}


