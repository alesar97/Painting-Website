@extends('app')
@section("content")

    <section class="contact-area" id="contact">
        <div class="contact-form-area section-padding gray-bg">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="area-title text-center">
                            <h3>GET IN TOUCH</h3>
                            <p>Need any help jusct send a message via our email address</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
                        <div class="contact-form">
                            <form action="{{route('contact.store')}}" id="contact-form" method="post">
                                <div class="row">
                                    @csrf
                                    {{--<input type="hidden" name="_token" id="_token_val" value="{{csrf_token()}}">--}}

                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <div class="form-group" id="name-field">
                                            <div class="form-input">
                                                <input type="text" class="form-control" id="form-name" name="name" placeholder="Name.." required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <div class="form-group" id="email-field">
                                            <div class="form-input">
                                                <input type="email" class="form-control" id="form-email" name="email" placeholder="Email.." required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                        <div class="form-group" id="phone-field">
                                            <div class="form-input">
                                                <input type="text" class="form-control" id="form-phone" name="phone" placeholder="Subject..">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                        <div class="form-group" id="message-field">
                                            <div class="form-input">
                                                <textarea class="form-control" rows="6" id="form-message" name="message" placeholder="Your Message Here..." required></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <button type="submit">Send</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                        <div class="contact-image">
                            <div class="contact-address">
                                <h4>Address</h4>
                                <p>Phone: <a href="callto:01744430440">+61466961561</a></p>
                                <p>Email: <a href="mailto:backpiper.com@gmail.com">backpiper.com@gmail.com</a></p>
                                <address>
                                    Office  :  29 road, Sec-08, Uttara-1204, Dhaka, Bangladesh.
                                </address>
                            </div>
                            <div class="social-bookmark">
                                <h4>Follow Us </h4>
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                    <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="map-area relative">
            <div id="map" style="width: 100%; height: 400px;"> </div>
        </div>
    </section>

@endsection
@push('myjs')

    <script>
        $(function () {

            $('#contact-form').submit(function (e) {

                e.preventDefault();

                $("#book_now").html('Sending..');


                $.ajax({

                    data: $('#contact-form').serialize(),

                    url: "{{ route('contact.store') }}",

                    type: "POST",

                    dataType: 'json',

                    success: function (data) {
                        $("#book_now").html("Send");
                        $("#_token_val").val('{{csrf_token()}}');

                        $('#contact-form').trigger("reset");


                        toastr.success(data.message);



                    },

                    error: function (data) {
                        $("#book_now").html("Book Now");
                        toastr.error(data.message );
                        $("#_token_val").val('{{csrf_token()}}');
                        console.log('Error:', data);


                    }

                });

            });
        });
    </script>
    @endpush