<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Transportation & Agency Template is a simple Smooth transportation and Agency Based Template" />
    <meta name="keywords" content="Portfolio, Agency, Onepage, Html, Business, Blog, Parallax" />


    <title>George Painting & Decorating</title>


    <link rel="shortcut icon" type="image/ico" href="{{asset('assets/img/favicon.ico')}}" />

    <link rel="stylesheet" href="{{asset('assets/css/normalize.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/animate.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/stellarnav.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/owl.carousel.css')}}">
    <link href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/font-awesome.min.css')}}" rel="stylesheet">


    <link href="{{asset('assets/style.css')}}" rel="stylesheet">
    <link href="{{asset('assets/css/responsive.css')}}}" rel="stylesheet">

    <script src="{{asset('assets/js/vendor/modernizr-2.8.3.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" ></script>
    <link href="{{asset('assets/css/foundation.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/css/twentytwenty.css')}}" rel="stylesheet" type="text/css" />
</head>

<body class="home-one">

<div class="preeloader">
    <div class="preloader-spinner"></div>
</div>


<a href="#home" class="scrolltotop"><i class="fa fa-long-arrow-up"></i></a>


<header class="top-area" id="home">
    <div class="top-area-bg" data-stellar-background-ratio="0.6"></div>
    <div class="header-top-area">

        <div class="mainmenu-area" id="mainmenu-area">
            <div class="mainmenu-area-bg"></div>
            <nav class="navbar">
                <div class="container">
                    <div class="navbar-header">
                        <a href="{{url('/')}}" class="navbar-brand">
                            <img src="{{asset('assets/img/logo_white.png')}}" style="width: 100px;height: 50px;" alt="logo"></a>
                    </div>
                    <div class="search-and-language-bar pull-right">


                    </div>
                    <div id="main-nav" class="stellarnav">
                        <ul id="nav" class="nav navbar-nav">
                            <li><a href="{{url('/')}}">home</a>

                            </li>

                            <li><a href="{{url('get-quote')}}">Get A Qute</a></li>
                            <li><a href="{{url('services')}}">Service</a></li>

                            <li class="has-sub"><a href="{{url('gallery/images')}}">Gallery</a>
                                <ul style="display: none;">
                                    <li class=""><a href="{{url('gallery/images')}}">    Images </a></li>
                                    <li class=""><a href="{{url('gallery/videos')}}"> Videos</a></li>

                                </ul>
                                <a class="dd-toggle" href="#"><i class="fa fa-plus"></i></a></li>

                            <li><a href="{{url('about')}}">About</a>
                            <li><a href="{{url('contact')}}">Contact</a>
                            <li class="has-sub"><a href="{{url('gallery/images')}}">Reviews</a>
                                <ul style="display: none;">
                                    <li class=""><a href="{{url('reviews/hipages')}}">    HiPages </a></li>
                                    <li class=""><a href="{{url('gallery/videos')}}"> Google</a></li>

                                </ul>
                                <a class="dd-toggle" href="#"><i class="fa fa-plus"></i></a></li>

                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

    </div>

    <div class="welcome-slider-area">
        <div class="welcome-single-slide slider-bg-one" style="background: url('{{asset("assets/img/slider/g_1.jpg")}}') no-repeat scroll center center / cover">
            <div class="container">
                <div class="row flex-v-center">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="welcome-text text-center">
                            <h1>Are You Looking For A Painter ?</h1>
                            <p>
                                Call Us Now : +61 466 961 561
                            </p>
                            <div class="home-button">
                                <a href="#">Our Service</a>
                                <a href="{{url('get-quote')}}">Get A Free Quate</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="welcome-single-slide slider-bg-two" style="background: url('{{asset("assets/img/slider/g2.jpg")}}') no-repeat scroll center center / cover">
            <div class="container">
                <div class="row flex-v-center">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="welcome-text text-center">
                            <h1>Are You Looking For A Painter</h1>

                            <p>
                                Call Us Now : +61 466 961 561
                            </p>
                            <div class="home-button">
                                <a href="#">Our Service</a>
                                <a href="#">Get A Quate</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</header>

@yield("content")

<div class="footer-area dark-bg">
    <div class="footer-area-bg"></div>
    <div class="footer-top-area wow fadeIn">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="footer-border"> </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom-area wow fadeIn">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="single-footer-widget footer-about">
                        <h3>About Us</h3>
                        <p>George Painting and Decorating.</p>
                        <ul>
                            <li><i class="fa fa-phone"></i> <a href="callto:+61466961561">+61 466 961 561</a></li>
                            <li><i class="fa fa-map-marker"></i> <a href="mailto:gpd.nsw@gmail.com">gpd.nsw@gmail.com</a></li>
                            <li><i class="fa fa-phone"></i> moriset NSW 2264 .</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="single-footer-widget twitter-widget">
                        <h3>Latest Tweets</h3>
                        <ul>
                            <li>
                                <div class="twitter-icon"><i class="fa fa-phone"></i></div>
                                <div class="tweet-detail">
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem .</p>
                                    <a href="#" class="tweet-meta">5 Miniutes Ago</a>
                                </div>
                            </li>
                            <li>
                                <div class="twitter-icon"><i class="fa fa-phone"></i></div>
                                <div class="tweet-detail">
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem .</p>
                                    <a href="#" class="tweet-meta">5 Miniutes Ago</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="single-footer-widget list-widget">
                        <h3>Customer Service</h3>
                        <ul>
                            <li><a href="#">Support Forums</a></li>
                            <li><a href="#">Communication</a></li>
                            <li><a href="#">FAQS</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Rules & Condition</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="single-footer-widget instafeed-widget">
                        <h3>Customer Service</h3>
                        <ul>
                            <li><a href="#"><img src="{{asset('img/instafeed/1.JPG')}}" alt=""></a></li>
                            <li><a href="#"><img src="{{asset('img/instafeed/2.JPG')}}" alt=""></a></li>
                            <li><a href="#"><img src="{{asset('img/instafeed/3.JPG')}}" alt=""></a></li>
                            <li><a href="#"><img src="{{asset('img/instafeed/4.JPG')}}" alt=""></a></li>
                            <li><a href="#"><img src="{{asset('img/instafeed/5.JPG')}}" alt=""></a></li>
                            <li><a href="#"><img src="{{asset('img/instafeed/6.JPG')}}" alt=""></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="footer-border"> </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="footer-copyright wow fadeIn">

                        <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This Website is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by  Hasan Ali </p>

                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="footer-social-bookmark text-right wow fadeIn">
                        <ul class="social-bookmark">
                            <li><a href="https://www.facebook.com/GPD.NSW/"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://www.instagram.com/gpd.nsw/"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-behance"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="{{asset('assets/js/vendor/jquery-1.12.4.min.js')}}"></script>
<script src="{{asset('assets/js/vendor/bootstrap.min.js')}}"></script>

<script src="{{asset('assets/js/vendor/jquery.easing.1.3.js')}}"></script>
<script src="{{asset('assets/js/vendor/jquery-migrate-1.2.1.min.js')}}"></script>
<script src="{{asset('assets/js/vendor/jquery.appear.js')}}"></script>
<script src="{{asset('assets/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('assets/js/stellar.js')}}"></script>
<script src="{{asset('assets/js/wow.min.js')}}"></script>
<script src="{{asset('assets/js/stellarnav.min.js')}}"></script>
{{--<script src="{{asset('assets/js/contact-form.js')}}"></script>--}}
<script src="{{asset('assets/js/jquery.sticky.js')}}"></script>

<script src="{{asset('assets/js/main.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js" ></script>

<!--gallery-->
<script src="{{asset('assets/js/jquery.event.move.js')}}"></script>
<script src="{{asset('assets/js/jquery.twentytwenty.js')}}"></script>
<script>
    $(function(){
        $(".twentytwenty-container[data-orientation!='vertical']").twentytwenty({default_offset_pct: 0.7});
        $(".twentytwenty-container[data-orientation='vertical']").twentytwenty({default_offset_pct: 0.3, orientation: 'vertical'});
    });
</script>
</body>

</html>
@stack("myjs")